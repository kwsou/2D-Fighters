package Game.Mechanics;
import java.awt.*;
import javax.swing.*;
import Graphics.*;
import Map.*;
import TileState.*;

public class GameCursor {

	public int xGameCursor, yGameCursor;
	
	public static final int gameCursorWidth = 64;
	public static final int gameCursorHeight = 64;
	public static final int gameCursorHoriSpeed = 64;
	public static final int gameCursorVertiSpeed = 64;
	
	public GameCursor(int x, int y){
		xGameCursor = x;
		yGameCursor = y;
	}
	
	/** Method moveGameCursorHorizontally()
	 * For references, the direction dictates in what direction
	 * the game cursor will move in horizontally. A negative
	 * value for direction indicates LEFT whereas
	 * a positive value for direction indicates RIGHT.
	 */
	public void moveGameCursorHorizontally(int direction){
		if (direction < 0){
			if ( isGameCursorWithinLeftBorder() ){
				xGameCursor += (direction * gameCursorHoriSpeed);
			}
		} else {	
			if ( isGameCursorWithinRightBorder() ){
				xGameCursor += (direction * gameCursorHoriSpeed);
			}
		}
	}
	
	/** Method moveGamecursorVertically()
	 * For references, the direction dictates in what direction
	 * the game cursor will move in vertically. A negative
	 * value for direction indicates UP whereas a positive
	 * value for direction indicates DOWN.
	 */
	public void moveGameCursorVertically(int direction){
		if (direction < 0){
			if ( isGameCursorWithinTopBorder() ){
				yGameCursor += (direction * gameCursorVertiSpeed);
			}
		} else {
			if ( isGameCursorWithinBottomBorder() ){
				yGameCursor += (direction * gameCursorVertiSpeed);
			}
		}
	}
	
	public boolean isGameCursorWithinTopBorder(){
		int yNextMoveUp = yGameCursor - gameCursorVertiSpeed;
		boolean isOutOfTopBorder = yNextMoveUp <= (CurrentMap.getTopBorderTileNumber() * State.tileSize);
		
		if (isOutOfTopBorder){
			return false;
		} else {
			return true;
		}
	}
	
	public boolean isGameCursorWithinBottomBorder(){
		int yNextMoveDown = yGameCursor + gameCursorVertiSpeed;
		boolean isOutOfBottomBorder = yNextMoveDown >= (CurrentMap.getBottomBorderTileNumber() * State.tileSize);
		
		if (isOutOfBottomBorder){
			return false;
		} else {
			return true;
		}
	}
	
	public boolean isGameCursorWithinLeftBorder(){
		int xNextMoveLeft = xGameCursor - gameCursorHoriSpeed;
		boolean isOutOfLeftBorder = xNextMoveLeft <= (CurrentMap.getLeftBorderTileNumber() * State.tileSize);
				
		if (isOutOfLeftBorder){
			return false;
		} else {
			return true;
		}
	}
	
	public boolean isGameCursorWithinRightBorder(){
		int xNextMoveRight = xGameCursor + gameCursorHoriSpeed;
		boolean isOutOfRightBorder = xNextMoveRight >= (CurrentMap.getRightBorderTileNumber() * State.tileSize);
		
		System.out.println(xNextMoveRight + ", " + (CurrentMap.getRightBorderTileNumber() * State.tileSize));
		
		if (isOutOfRightBorder){
			return false;
		} else {
			return true;
		}
	}
	
	public void drawCursor(Graphics g, JPanel playPanel){
		g.drawImage(ImageTracker.GameCursor, xGameCursor, yGameCursor, playPanel);
	}
}
