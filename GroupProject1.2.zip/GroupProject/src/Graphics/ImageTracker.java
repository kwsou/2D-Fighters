package Graphics;
import java.awt.*;

import javax.swing.*;

public class ImageTracker {

	// Tile Images
	public static Image GroundTile, WallTile, WaterTile;
	
	// Game Cursor Image
	public static Image GameCursor;
	
	public static MediaTracker imageTracker;
	Toolkit imageExtractor;
	
	public ImageTracker(JFrame gameWindow){
		imageExtractor = Toolkit.getDefaultToolkit();
		imageTracker = new MediaTracker(gameWindow);
	}
	
	public void setUpTileImages(){
		GroundTile = imageExtractor.getImage("images/tiles/GroundTile.png");
		WallTile = imageExtractor.getImage("images/tiles/WallTile.png");
		WaterTile = imageExtractor.getImage("images/tiles/WaterTile.png");
		
		imageTracker.addImage(GroundTile, 0);
		imageTracker.addImage(WallTile, 1);
		imageTracker.addImage(WaterTile, 2);
	}
	
	public void setUpGameCursorImages(){
		GameCursor = imageExtractor.getImage("images/cursor/GameCursor/GameCursor.gif");
		imageTracker.addImage(GameCursor, 3);
	}
	
}
