package Game;
import java.awt.*;
import javax.swing.*;

public class GameWindow extends JFrame {
	public static int defaultX, defaultY;
	MainGame mainGame;
	
	public GameWindow(){
		super("Group Project");
		
		defaultX = 730;
		defaultY = 550;
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(defaultX, defaultY);
		setResizable(true);
//		setUndecorated(true);
		
		mainGame = new MainGame(this);
		mainGame.setUpGUI();
		add(mainGame);
		
		mainGame.setFocusable(true);
		setVisible(true);
		
//		this.pack();
		do{
			mainGame.run();
		} while (true);
	}
	
	public static void main (String [] args){
		new GameWindow();
	}
}
