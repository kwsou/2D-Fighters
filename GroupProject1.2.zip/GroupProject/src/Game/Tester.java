package Game;
import java.awt.*;
import TileState.*;

public class Tester {
	
	public static void main(String [] args){
		State tile[][] = new State[3][3];
		
		for (int n = 0; n < 3;n ++){
			for (int m = 0; m < 3; m++){
				if (n%2 == 0){
					tile[m][n] = new GroundTile(n, m);
				} else {
					tile[m][n] = new WallTile(n, m);
				}
				tile[m][n].paintTile();
			}
		}
	}

}
