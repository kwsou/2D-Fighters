package Game.Mechanics;
import java.util.*;

/*** RandomNumberGenerator.java
 * This class is for generating random numbers that will decide for the
 * game what action to preform (ie. if the player attacks a monster
 * with a 70% of hitting, this class will be used to see if the player
 * will hit or not hit.
 */

public class RandomNumberGenerator {
	
	private int playerCON, playerMOV,
				playerGrowth[], playerStatGain[];
	public static final int totalPlayerStats = 6;
	
	Random generator;
	
	public RandomNumberGenerator(){
		generator = new Random();
	}
	
	public void setUpCharacter(int HP, int POW, int SKL, int SPD, int LUC, int DEF, int CON, int MOV){
		setUpCharacterGrowth(HP, POW, SKL, SPD, LUC, DEF);
		this.playerCON = CON;
		this.playerMOV = MOV;
	}
	
	public void setUpCharacterGrowth(int HP, int POW, int SKL, int SPD, int LUC, int DEF){
		playerGrowth = new int[totalPlayerStats];
		
		playerGrowth[0] = HP;
		playerGrowth[1] = POW;
		playerGrowth[2] = SKL;
		playerGrowth[3] = SPD;
		playerGrowth[4] = LUC;
		playerGrowth[5] = DEF;
	}
	
	public boolean checkPercentage(int testingCondition){
		/*
		 * random generated numbers are decided based on Simple Random Sampling
		 */
		
		int sample = generator.nextInt(101);
		
		if (sample <= testingCondition){
			return true;
		} else {
			return false;
		}
	}
	
	public int[] getPlayerStatGain(){
		playerStatGain = new int[totalPlayerStats];
		
		for (int n = 0; n < totalPlayerStats; n++){
			if ( checkPercentage(playerGrowth[n]) ){
				playerStatGain[n] = 1;
			} else {
				playerStatGain[n] = 0;
			}
		}
		return playerStatGain;
	}
	
}
