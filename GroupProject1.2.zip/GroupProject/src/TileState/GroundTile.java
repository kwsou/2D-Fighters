package TileState;
import java.awt.*;
import javax.swing.*;
import Graphics.*;

public class GroundTile extends State {
	
	public GroundTile(int x, int y, ImageTracker imgTracker){
		super(x, y, imgTracker);
		tileIdentity = 1;
	}
	
	public void paintTile(Graphics g, JPanel playPanel){
		g.drawImage(imgTracker.GroundTile, xTileRelative, yTileRelative, playPanel);
	}
	
}
