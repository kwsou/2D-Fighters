package Game;
import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.event.*;
import java.awt.event.*;

import Graphics.*;
import Map.*;
import GUI.*;
import MouseCursor.*;

public class MainGame extends JPanel implements Runnable, KeyListener, MouseInputListener {

	public static boolean isGameRunning = false, isGameOn = false;
	public static Dimension playPanelSize;
	
	private ScreenManager painter;
	private PlayPanel playPanel;
	
	public MouseCursor mouseCursor;
	private MapManager mapManager;
	private ImageTracker imageTracker;

	public MainGame(JFrame gameWindow){
		super();
		addKeyListener(this);
		addMouseListener(this);
		addMouseMotionListener(this);
		
		playPanelSize = new Dimension(512, 512);
		
		painter = new ScreenManager();
		
		mouseCursor = new MouseCursor(this);
		imageTracker = new ImageTracker(gameWindow);
		mapManager = new MapManager(imageTracker);
	}
	
	public void run(){
		if (isGameRunning){
			if (!isGameOn){
				mapManager.start();
				isGameOn = true;
			}
			
			try {
				mainGameWork();
				repaint();
				Thread.sleep(2);
			} catch (InterruptedException e) {}
		}
	}
	
	public void mainGameWork(){

	}
	
	public void paintComponent(Graphics g){
		playPanel.paintComponents(g);
		mouseCursor.drawCursor(g);
	}
	
	public void setUpGUI(){
//		setLayout(new BoxLayout(this, BoxLayout.Y_AXIS) );
		setLayout(new FlowLayout(FlowLayout.CENTER, 3, 0) );
//		setBorder(new EmptyBorder(new Insets(0, 0, 0, 0) ) );
		
		playPanel = new PlayPanel(painter, mapManager.currentMap);
		playPanel.setPreferredSize( playPanelSize );
		playPanel.setMaximumSize( playPanelSize );
		playPanel.setBorder(BorderFactory.createLineBorder(Color.black));
		add(playPanel);
		
		JPanel takeUpSpace1 = new JPanel();
		takeUpSpace1.setPreferredSize( new Dimension (200, 518) );
		takeUpSpace1.setBorder(BorderFactory.createLineBorder(Color.black) );
		
		takeUpSpace1.add(new JLabel("TakeUpSpace1 Panel"));
		takeUpSpace1.add(new JTextArea("This is just to plan \nthe size of the JFrame.", 5, 15) );
		
		add(takeUpSpace1);
	}
	
	////////////////////
	//** KEYBOARD ***///
	
	public void keyPressed(KeyEvent evt) {           
		 int key = evt.getKeyCode();
		 
		 if(key == KeyEvent.VK_SPACE){
			 isGameRunning = true;
		 }
		 
		 switch(key){
		 case KeyEvent.VK_UP:
			 playPanel.isGameCursorUp = true;
			 break;
		 case KeyEvent.VK_DOWN:
			 playPanel.isGameCursorDown = true;
			 break;
		 case KeyEvent.VK_LEFT:
			 playPanel.isGameCursorLeft = true;
			 break;
		 case KeyEvent.VK_RIGHT:
			 playPanel.isGameCursorRight = true;
			 break;
		 }
	}
	
	public void keyReleased(KeyEvent evt){
		int key = evt.getKeyCode();
		
		switch(key){
		 case KeyEvent.VK_UP:
			 playPanel.isGameCursorUp = false;
			 break;
		 case KeyEvent.VK_DOWN:
			 playPanel.isGameCursorDown = false;
			 break;
		 case KeyEvent.VK_LEFT:
			 playPanel.isGameCursorLeft = false;
			 break;
		 case KeyEvent.VK_RIGHT:
			 playPanel.isGameCursorRight = false;
			 break;
		 }
	}
	public void keyTyped(KeyEvent evt){
		//needed just to be there
	}
	
	
	////////////////////
	//**** MOUSE ****///
	public void mouseMoved(MouseEvent e) {
		MouseCursor.xCursor = e.getX();
		MouseCursor.yCursor = e.getY();
	}
	public void mouseDragged(MouseEvent e) {
	}
	public void mouseEntered(MouseEvent e){
	}
	public void mouseExited(MouseEvent e){
	}
	public void mousePressed(MouseEvent e){
	}
	public void mouseReleased(MouseEvent e){
	}
	public void mouseClicked(MouseEvent e){
		System.out.println(e.getX() + ", " + e.getY() );
	}
}
