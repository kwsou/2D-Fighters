package Graphics;
import java.awt.*;
import javax.swing.*;

import Game.Mechanics.*;
import Map.*;

public class ScreenManager {

	public void erasePlayPanel(Graphics g, int x, int y){
		g.setColor(Color.white);
		g.fillRect(0, 0, x, y);
	}
	
	public void drawPlayPanel(Graphics g, CurrentMap currentMap, JPanel playPanel){
		drawMap(g, currentMap, playPanel);
		drawGameCursor(g, currentMap, playPanel);
	}
	
	public void drawMap(Graphics g, CurrentMap currentMap, JPanel playPanel){
		for (int currentRow = 0; currentRow < currentMap.tileMapHeight; currentRow ++){
			for (int currentColumn = 0; currentColumn < currentMap.tileMapWidth; currentColumn++){
				currentMap.tiles[currentColumn][currentRow].paintTile(g, playPanel);
			}
		}
	}
	
	public void drawGameCursor(Graphics g, CurrentMap currentMap, JPanel playPanel){
		try {
			currentMap.gameCursor.drawCursor(g, playPanel);
		} catch (NullPointerException e ){ }
	}
	
}
