package Map;
import java.util.*;
import java.io.*;

import TileState.*;
import Graphics.*;
import Game.Mechanics.*;

public class CurrentMap {

	public static int tileMapWidth, tileMapHeight, numberOfTiles;
	private int tempMapRow, tempMapColumn;
	
	public ImageTracker imgTracker;
	public State tiles[][];
	public GameCursor gameCursor;
	
	ArrayList<String> tileMapLines;
	BufferedReader textFileReader;
	
	public CurrentMap(ImageTracker imgTracker){
		this.imgTracker = imgTracker;
	}
	
	public void loadCurrentMap(String fileName) throws IOException{
		getMapDimensions(fileName);
		setUpTiles();
	}
	
	public void getMapDimensions(String fileName) throws IOException {
		resetMapValues();
		tileMapLines = new ArrayList();
		
		try {
			textFileReader = new BufferedReader(new FileReader(fileName) );
		} catch (FileNotFoundException e){
			System.out.println("Did not find text file! Make sure it's named correctly. Exiting game.");
			System.exit(0);
		}
		
		while (true){
			String currentLine = textFileReader.readLine();
			
			if (currentLine == null){
				textFileReader.close();
				break;
			}
			
			if (!currentLine.startsWith("%")){
				tileMapLines.add(currentLine);
				if (currentLine.length() > tileMapWidth){
					tileMapWidth = currentLine.length();
				}
			}
		}
		
		tileMapHeight = tileMapLines.size();
		tiles = new State[tileMapWidth][tileMapHeight];
	}
	
	public void setUpTiles(){
		for (int currentMapRow = 0; currentMapRow < tileMapHeight; currentMapRow++){
			String currentLine = (String)tileMapLines.get(currentMapRow);
			for (int currentMapColumn = 0; currentMapColumn < currentLine.length(); currentMapColumn++){
				char tileType = currentLine.charAt(currentMapColumn);
				numberOfTiles++;
				
				/****** Tile Type Legend *******
				 * 		'G' <- Ground Tile		
				 * 		'W' <- Wall Tile
				 * 		'A' <- Water Tile
				 * 
				 *** Special Cases ***
				 *		'C' <- Position of player/character
				 */
				
				if (tileType == 'G'){
					tiles[currentMapColumn][currentMapRow] = new GroundTile(currentMapColumn, currentMapRow, imgTracker);
				} else if (tileType == 'W'){
					tiles[currentMapColumn][currentMapRow] = new WallTile(currentMapColumn, currentMapRow, imgTracker);
				} else if (tileType == 'A'){
					tiles[currentMapColumn][currentMapRow] = new WaterTile(currentMapColumn, currentMapRow, imgTracker);
				}
				// Checks if enemy is on the tile - MUST be ground tile then
				else if (Character.isDigit(tileType) ){
					tiles[currentMapColumn][currentMapRow] = new GroundTile(currentMapColumn, currentMapRow, imgTracker);
				}
				// Checks for player's position - MUST be ground tile then
				else if (tileType == 'C'){
					System.out.println("created!");
					gameCursor = new GameCursor( (currentMapColumn * State.tileSize), (currentMapRow * State.tileSize) );
					tiles[currentMapColumn][currentMapRow] = new GroundTile(currentMapColumn, currentMapRow, imgTracker);
				}
				
			}
		}
	}
	
	public void resetMapValues(){
		numberOfTiles = 0;
		tileMapWidth = 0;
		tileMapHeight = 0;
		tempMapRow = 0;
		tempMapColumn = 0;
	}
	
	public static int getRightBorderTileNumber(){
		return tileMapWidth;
	}
	public static int getBottomBorderTileNumber(){
		return tileMapHeight;
	}
	public static int getLeftBorderTileNumber(){
		return -1;
	}
	public static int getTopBorderTileNumber(){
		return -1;
	}
	
}
