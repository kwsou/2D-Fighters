package TileState;
import java.awt.Graphics;
import javax.swing.*;
import Graphics.*;

public class WaterTile extends State {

	public WaterTile(int x, int y, ImageTracker imgTracker){
		super (x, y, imgTracker);
		tileIdentity = 3;
	}
	
	public void paintTile(Graphics g, JPanel playPanel){
		g.drawImage(imgTracker.WaterTile, xTileRelative, yTileRelative, playPanel);
	}
	
}
