package GUI;
import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Timer;
import java.util.TimerTask;

import Game.*;
import Graphics.*;
import Map.*;

public class PlayPanel extends JPanel implements MouseInputListener{
	
	public boolean isGameCursorLeft, isGameCursorRight, isGameCursorUp, isGameCursorDown;
	public int gameCursorMoveDelay;
	
	ScreenManager painter;
	CurrentMap currentMap;
	
	Timer gameCursorMoveTimer;
	
	public PlayPanel(ScreenManager painter, CurrentMap currentMap){
		this.painter = painter;
		this.currentMap = currentMap;

		addMouseListener(this);
		addMouseMotionListener(this);
		
		isGameCursorLeft = false;
		isGameCursorRight = false;
		isGameCursorUp = false;
		isGameCursorDown = false;

		gameCursorMoveDelay = 50;
		
		gameCursorMoveTimer = new Timer();
		gameCursorMoveTimer.scheduleAtFixedRate(new GameCursorMoveTimer(), 0, gameCursorMoveDelay);
	}
	
	public void paint(Graphics g){
		painter.erasePlayPanel(g, 500, 500);
		painter.drawPlayPanel(g, currentMap, this);
	}
	
	////////////////////
	//**** MOUSE ****///
	public void mouseMoved(MouseEvent e) {
	}
	public void mouseDragged(MouseEvent e) {
	}
	public void mouseEntered(MouseEvent e){
	}
	public void mouseExited(MouseEvent e){
	}
	public void mousePressed(MouseEvent e){
	}
	public void mouseReleased(MouseEvent e){
	}
	public void mouseClicked(MouseEvent e){
		System.out.println("Clicked in Play Panel!");
	}
	
	class GameCursorMoveTimer extends TimerTask {
		public void run(){
			try {
				if (isGameCursorUp){
					currentMap.gameCursor.moveGameCursorVertically(-1);
				} else if (isGameCursorDown){
					currentMap.gameCursor.moveGameCursorVertically(1);
				}


				if(isGameCursorLeft){
					currentMap.gameCursor.moveGameCursorHorizontally(-1);
				} else if (isGameCursorRight){
					currentMap.gameCursor.moveGameCursorHorizontally(1);
				}
			} catch (NullPointerException e) {}
		}
	}

}
