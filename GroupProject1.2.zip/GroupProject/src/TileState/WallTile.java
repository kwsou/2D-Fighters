package TileState;
import java.awt.*;

import javax.swing.*;

import Graphics.*;

public class WallTile extends State {

	public WallTile(int x, int y, ImageTracker imgTracker ){
		super(x, y, imgTracker);
		tileIdentity = 2;
	}
	
	public void paintTile(Graphics g, JPanel playPanel){
		g.drawImage(imgTracker.WallTile, xTileRelative, yTileRelative, playPanel);
	}
	
}
