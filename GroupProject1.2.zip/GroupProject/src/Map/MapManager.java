package Map;
import java.io.IOException;
import Graphics.*;

public class MapManager {

	public static int currentLevel;
	
	public CurrentMap currentMap;
	ImageTracker imgTracker;
	
	public MapManager(ImageTracker imgTracker){
		this.imgTracker = imgTracker;
		currentMap = new CurrentMap(imgTracker);
		currentLevel = 1;
	}
	
	public void start(){
		imgTracker.setUpTileImages();
		imgTracker.setUpGameCursorImages();
		try {
			ImageTracker.imageTracker.waitForAll();
		} catch (InterruptedException e) {}
		loadNextMap();
	}
	
	public void loadNextMap(){
		currentLevel++;
		try {
			ImageTracker.imageTracker.waitForAll();
			currentMap.loadCurrentMap("src/Levels/Level" + currentLevel + ".txt");
		} catch (IOException e) {}
		catch (InterruptedException e){}
	}
	
}
