package Game.Mechanics;
import Game.*;
import Map.*;
import TileState.*;

public class GameScroller {

	public int xActualScreenSize, yActualScreenSize,
			xScreenSize, yScreenSize,
			currentXLocation, currentYLocation;
	public static final int horiScrollSpeed = 64;
	public static final int vertiScrollSpeed = 64;
	
	public GameScroller(){
		xScreenSize = (int)MainGame.playPanelSize.getWidth();
		yScreenSize = (int)MainGame.playPanelSize.getHeight();
		
		xActualScreenSize = CurrentMap.getRightBorderTileNumber() * State.tileSize;
		yActualScreenSize = CurrentMap.getBottomBorderTileNumber() * State.tileSize;
		
		currentXLocation = 0;
		currentYLocation = 0;
	}
	
	public boolean isGameCursorOnLeftEdge(int xGameCursor){
		boolean isOnLeftEdge = xGameCursor <= currentXLocation;
		if (isOnLeftEdge){
			return true;
		} else {
			return false;
		}
	}
	
	public boolean isGameCursorOnRightEdge(int xGameCursor){
		boolean isOnRightEdge = xGameCursor >= (currentXLocation + xScreenSize - GameCursor.gameCursorWidth);
		if (isOnRightEdge){
			return true;
		} else {
			return false;
		}
	}
	
	public boolean isGameCursorOnTopEdge(int yGameCursor){
		boolean isOnTopEdge = yGameCursor <= currentYLocation;
		if (isOnTopEdge){
			return true;
		} else {
			return false;
		}
	}
	
	public boolean isGameCursorOnBottomEdge(int yGameCursor){
		boolean isOnBottomEdge = yGameCursor <= currentYLocation;
		if (isOnBottomEdge){
			return true;
		} else {
			return false;
		}
	}
	
}
