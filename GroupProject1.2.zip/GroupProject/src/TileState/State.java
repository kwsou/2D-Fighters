package TileState;
import java.awt.*;
import javax.swing.*;
import Graphics.*;

public class State {

	public static final int tileSize = 64;
	public int xTile, yTile, xTileRelative, yTileRelative;
	public int tileIdentity;
	
	public char tileType;
	public boolean isStateInView;
	
	ImageTracker imgTracker;
	
	public State(int x, int y, ImageTracker imgTracker){
		xTile = x;
		yTile = y;
		xTileRelative = xTile * tileSize;
		yTileRelative = yTile * tileSize;
		
		this.imgTracker = imgTracker;
	}
	
	public int getTileX(){ return xTile; }
	public int getTileY(){ return yTile; }
	public int getTileXScreenPosition(){ return xTileRelative; }
	public int getTileYScreenPosition(){ return yTileRelative; }
	
	public void moveTileHorizontally(int scrollSpeed){
		xTileRelative += scrollSpeed;
	}
	
	public void moveTileVertically(int scrollSpeed){
		yTileRelative += scrollSpeed;
	}
	
	public void paintTile(Graphics g, JPanel playPanel){
	}
	
//	public void 
	
}
