package MouseCursor;
import java.awt.*;

public class MouseCursor extends Cursor {
	
	public Cursor cursor;
	public static int xCursor = 500, yCursor = 500;
	public static final int CursorLength = 30;
	public static final int CursorHeight = 38;
	
	public MouseCursor(Component c){
		super("normal cursor");
		Toolkit toolkit = Toolkit.getDefaultToolkit();  
		Point hotSpot = new Point(0,0); 
		cursor = toolkit.createCustomCursor( toolkit.getImage("images/cursor/MouseCursor.png"), new java.awt.Point(0,0), "Game Cursor");
		c.setCursor(cursor);
	}
	
	public void drawCursor(Graphics g){
	}
}
